namespace MinimalApiDemo.Exceptions;

/// <summary>Thrown when a requested resource does not exist. Maps to HTTP 404.</summary>
public sealed class NotFoundException(string message) : Exception(message);

/// <summary>Thrown when a request fails business/validation rules. Maps to HTTP 400.</summary>
public sealed class ValidationException(string message) : Exception(message);
