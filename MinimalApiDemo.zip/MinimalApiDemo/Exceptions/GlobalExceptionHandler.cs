using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace MinimalApiDemo.Exceptions;

/// <summary>
/// Catches unhandled exceptions anywhere in the request pipeline and turns them
/// into a consistent RFC 7807 ProblemDetails response. Registered via
/// <c>AddExceptionHandler</c> + <c>UseExceptionHandler</c> in Program.cs.
/// </summary>
public sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetailsService,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // Map known exception types to status codes; everything else is a 500.
        var (statusCode, title) = exception switch
        {
            NotFoundException => (StatusCodes.Status404NotFound, "Resource not found"),
            ValidationException => (StatusCodes.Status400BadRequest, "Validation failed"),
            _ => (StatusCodes.Status500InternalServerError, "An unexpected error occurred"),
        };

        // Log server errors loudly; client errors (4xx) are expected, so log lighter.
        if (statusCode >= 500)
            logger.LogError(exception, "Unhandled exception processing {Path}", httpContext.Request.Path);
        else
            logger.LogWarning("Request to {Path} failed: {Message}", httpContext.Request.Path, exception.Message);

        httpContext.Response.StatusCode = statusCode;

        // Never leak internal exception details on a 500.
        var detail = statusCode >= 500 ? "An internal error occurred. Please try again later." : exception.Message;

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            Exception = exception,
            ProblemDetails = new ProblemDetails
            {
                Status = statusCode,
                Title = title,
                Detail = detail,
                Type = $"https://httpstatuses.io/{statusCode}",
            },
        });
    }
}
