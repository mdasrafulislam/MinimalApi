using System.Collections.Concurrent;
using MinimalApiDemo.Models;

namespace MinimalApiDemo.Data;

/// <summary>
/// A simple thread-safe in-memory store seeded with sample data.
/// Swap this out for a real database / repository (e.g. EF Core) later —
/// the endpoints only depend on these methods, not on how data is stored.
/// </summary>
public sealed class CatalogStore
{
    private readonly ConcurrentDictionary<int, Product> _products = new();
    private readonly ConcurrentDictionary<int, Category> _categories = new();
    private int _nextProductId;
    private int _nextCategoryId;

    public CatalogStore()
    {
        // Seed a couple of categories and products.
        var electronics = AddCategory("Electronics");
        var books = AddCategory("Books");

        AddProduct("Wireless Mouse", 24.99m, electronics.Id);
        AddProduct("Mechanical Keyboard", 79.99m, electronics.Id);
        AddProduct("Clean Code", 32.50m, books.Id);
    }

    // ---- Categories ----

    public IReadOnlyCollection<Category> GetCategories() => _categories.Values.ToList();

    public Category? GetCategory(int id) => _categories.GetValueOrDefault(id);

    public bool CategoryExists(int id) => _categories.ContainsKey(id);

    public Category AddCategory(string name)
    {
        var id = Interlocked.Increment(ref _nextCategoryId);
        var category = new Category(id, name);
        _categories[id] = category;
        return category;
    }

    public Category? UpdateCategory(int id, string name)
    {
        if (!_categories.ContainsKey(id)) return null;
        var updated = new Category(id, name);
        _categories[id] = updated;
        return updated;
    }

    public bool DeleteCategory(int id) => _categories.TryRemove(id, out _);

    // ---- Products ----

    public IReadOnlyCollection<Product> GetProducts() => _products.Values.ToList();

    public Product? GetProduct(int id) => _products.GetValueOrDefault(id);

    public Product AddProduct(string name, decimal price, int categoryId)
    {
        var id = Interlocked.Increment(ref _nextProductId);
        var product = new Product(id, name, price, categoryId);
        _products[id] = product;
        return product;
    }

    public Product? UpdateProduct(int id, string name, decimal price, int categoryId)
    {
        if (!_products.ContainsKey(id)) return null;
        var updated = new Product(id, name, price, categoryId);
        _products[id] = updated;
        return updated;
    }

    public bool DeleteProduct(int id) => _products.TryRemove(id, out _);
}
