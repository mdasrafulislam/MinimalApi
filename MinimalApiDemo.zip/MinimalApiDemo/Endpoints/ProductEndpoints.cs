using MinimalApiDemo.Data;
using MinimalApiDemo.Exceptions;
using MinimalApiDemo.Models;

namespace MinimalApiDemo.Endpoints;

/// <summary>
/// Product endpoints. Kept out of Program.cs by exposing a single
/// <see cref="MapProductEndpoints"/> extension that Program.cs calls.
/// </summary>
public static class ProductEndpoints
{
    public static IEndpointRouteBuilder MapProductEndpoints(this IEndpointRouteBuilder app)
    {
        // A route group keeps the shared prefix and OpenAPI tag in one place.
        var group = app.MapGroup("/api/products")
            .WithTags("Products");

        group.MapGet("/", (CatalogStore store) => Results.Ok(store.GetProducts()))
            .WithName("GetProducts")
            .WithSummary("List all products")
            .WithDescription("Returns every product currently in the catalog.")
            .Produces<IEnumerable<Product>>(StatusCodes.Status200OK);

        group.MapGet("/{id:int}", (int id, CatalogStore store) =>
            {
                var product = store.GetProduct(id)
                    ?? throw new NotFoundException($"Product {id} was not found.");
                return Results.Ok(product);
            })
            .WithName("GetProductById")
            .WithSummary("Get a product by id")
            .WithDescription("Returns a single product, or a 404 ProblemDetails if it does not exist.")
            .Produces<Product>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapPost("/", (ProductRequest request, CatalogStore store) =>
            {
                Validate(request, store);
                var product = store.AddProduct(request.Name, request.Price, request.CategoryId);
                return Results.CreatedAtRoute("GetProductById", new { id = product.Id }, product);
            })
            .WithName("CreateProduct")
            .WithSummary("Create a new product")
            .WithDescription("Validates the payload and adds a product. Returns 201 with a Location header.")
            .Produces<Product>(StatusCodes.Status201Created)
            .ProducesProblem(StatusCodes.Status400BadRequest);

        group.MapPut("/{id:int}", (int id, ProductRequest request, CatalogStore store) =>
            {
                Validate(request, store);
                var updated = store.UpdateProduct(id, request.Name, request.Price, request.CategoryId)
                    ?? throw new NotFoundException($"Product {id} was not found.");
                return Results.Ok(updated);
            })
            .WithName("UpdateProduct")
            .WithSummary("Replace an existing product")
            .Produces<Product>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status400BadRequest)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapDelete("/{id:int}", (int id, CatalogStore store) =>
            {
                if (!store.DeleteProduct(id))
                    throw new NotFoundException($"Product {id} was not found.");
                return Results.NoContent();
            })
            .WithName("DeleteProduct")
            .WithSummary("Delete a product")
            .Produces(StatusCodes.Status204NoContent)
            .ProducesProblem(StatusCodes.Status404NotFound);

        return app;
    }

    // Throws ValidationException -> handled globally and returned as a 400 ProblemDetails.
    private static void Validate(ProductRequest request, CatalogStore store)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            throw new ValidationException("Product name is required.");
        if (request.Price < 0)
            throw new ValidationException("Price cannot be negative.");
        if (!store.CategoryExists(request.CategoryId))
            throw new ValidationException($"Category {request.CategoryId} does not exist.");
    }
}
