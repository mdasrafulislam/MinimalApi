using MinimalApiDemo.Data;
using MinimalApiDemo.Exceptions;
using MinimalApiDemo.Models;

namespace MinimalApiDemo.Endpoints;

/// <summary>
/// Category endpoints, mapped via <see cref="MapCategoryEndpoints"/>.
/// </summary>
public static class CategoryEndpoints
{
    public static IEndpointRouteBuilder MapCategoryEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/categories")
            .WithTags("Categories");

        group.MapGet("/", (CatalogStore store) => Results.Ok(store.GetCategories()))
            .WithName("GetCategories")
            .WithSummary("List all categories")
            .WithDescription("Returns every product category.")
            .Produces<IEnumerable<Category>>(StatusCodes.Status200OK);

        group.MapGet("/{id:int}", (int id, CatalogStore store) =>
            {
                var category = store.GetCategory(id)
                    ?? throw new NotFoundException($"Category {id} was not found.");
                return Results.Ok(category);
            })
            .WithName("GetCategoryById")
            .WithSummary("Get a category by id")
            .Produces<Category>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapPost("/", (CategoryRequest request, CatalogStore store) =>
            {
                if (string.IsNullOrWhiteSpace(request.Name))
                    throw new ValidationException("Category name is required.");

                var category = store.AddCategory(request.Name);
                return Results.CreatedAtRoute("GetCategoryById", new { id = category.Id }, category);
            })
            .WithName("CreateCategory")
            .WithSummary("Create a new category")
            .Produces<Category>(StatusCodes.Status201Created)
            .ProducesProblem(StatusCodes.Status400BadRequest);

        group.MapPut("/{id:int}", (int id, CategoryRequest request, CatalogStore store) =>
            {
                if (string.IsNullOrWhiteSpace(request.Name))
                    throw new ValidationException("Category name is required.");

                var updated = store.UpdateCategory(id, request.Name)
                    ?? throw new NotFoundException($"Category {id} was not found.");
                return Results.Ok(updated);
            })
            .WithName("UpdateCategory")
            .WithSummary("Replace an existing category")
            .Produces<Category>(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status400BadRequest)
            .ProducesProblem(StatusCodes.Status404NotFound);

        group.MapDelete("/{id:int}", (int id, CatalogStore store) =>
            {
                if (!store.DeleteCategory(id))
                    throw new NotFoundException($"Category {id} was not found.");
                return Results.NoContent();
            })
            .WithName("DeleteCategory")
            .WithSummary("Delete a category")
            .Produces(StatusCodes.Status204NoContent)
            .ProducesProblem(StatusCodes.Status404NotFound);

        return app;
    }
}
