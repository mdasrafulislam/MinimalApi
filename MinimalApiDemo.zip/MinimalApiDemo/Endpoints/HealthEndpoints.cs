namespace MinimalApiDemo.Endpoints;

/// <summary>
/// Health / diagnostics endpoints, mapped via <see cref="MapHealthEndpoints"/>.
/// </summary>
public static class HealthEndpoints
{
    public static IEndpointRouteBuilder MapHealthEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/health")
            .WithTags("Health");

        group.MapGet("/", () => Results.Ok(new { status = "Healthy", timestamp = DateTimeOffset.UtcNow }))
            .WithName("HealthCheck")
            .WithSummary("Service health check")
            .WithDescription("Returns a simple status payload to confirm the service is running.")
            .Produces(StatusCodes.Status200OK);

        // Handy for verifying the global exception handler returns a clean 500 ProblemDetails.
        group.MapGet("/boom", () =>
            {
                throw new InvalidOperationException("This is a deliberately thrown error.");
            })
            .WithName("TriggerError")
            .WithSummary("Trigger an unhandled error")
            .WithDescription("Always throws. Useful for confirming the global handler returns a 500 ProblemDetails.")
            .ProducesProblem(StatusCodes.Status500InternalServerError);

        return app;
    }
}
