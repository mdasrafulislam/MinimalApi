namespace MinimalApiDemo.Models;

/// <summary>A product in the catalog.</summary>
public sealed record Product(int Id, string Name, decimal Price, int CategoryId);

/// <summary>A category that groups products.</summary>
public sealed record Category(int Id, string Name);

/// <summary>Payload for creating or replacing a product.</summary>
public sealed record ProductRequest(string Name, decimal Price, int CategoryId);

/// <summary>Payload for creating or replacing a category.</summary>
public sealed record CategoryRequest(string Name);
