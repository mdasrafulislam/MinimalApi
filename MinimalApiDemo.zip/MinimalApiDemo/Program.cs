using MinimalApiDemo.Data;
using MinimalApiDemo.Endpoints;
using MinimalApiDemo.Exceptions;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// --- Services ---

// Generates the OpenAPI document served at /openapi/v1.json
builder.Services.AddOpenApi();

// Global exception handling -> consistent RFC 7807 ProblemDetails responses.
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();

// In-memory data store (replace with a real DB/repository later).
builder.Services.AddSingleton<CatalogStore>();

var app = builder.Build();

// --- Pipeline ---

// Must come early so it can catch exceptions from the endpoints below.
app.UseExceptionHandler();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();                          // /openapi/v1.json

    app.MapScalarApiReference(options =>       // interactive docs at /scalar/v1
    {
        options.WithTitle("Minimal API Demo")
               .WithTheme(ScalarTheme.Purple);
    });
}

app.UseHttpsRedirection();

// --- Endpoints (each group lives in its own file under /Endpoints) ---
app.MapProductEndpoints();
app.MapCategoryEndpoints();
app.MapHealthEndpoints();

app.Run();
